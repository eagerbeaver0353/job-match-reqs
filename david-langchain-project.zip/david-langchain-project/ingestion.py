import pinecone
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import PyPDFDirectoryLoader
import os

os.environ["OPENAI_API_KEY"] = "enter API key here"
pinecone.init(api_key="enter API key here",
              environment="us-central1-gcp")

data_folder_path = r"enter directory path here"

index_name = "article-storage"


# import env variables from .env file and set them as environment variables
# from dotenv import load_dotenv
# load_dotenv()


if __name__ == '__main__':
    loader = PyPDFDirectoryLoader(path=data_folder_path)

    # loader = PyPDFLoader(data_path)
    raw_documents = loader.load()
    # print('PyCharm')
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000, chunk_overlap=100, separators=["\n\n", "\n", " ", ""]
    )

    documents = text_splitter.split_documents(raw_documents)
    for document in documents:
        print(document.metadata["source"])

    embeddings = OpenAIEmbeddings()
    print("Adding all documents to the vector store")
    Pinecone.from_documents(
        documents=documents, embedding=embeddings, index_name=index_name)
    print("Embedded all documents and added them to the vector store on Pinecone!")

    # text splitter
