from typing import List, Dict, Any

import pinecone
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Pinecone
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain


pinecone.init(api_key="enter key here",
              environment="us-central1-gcp")

index_name = "article-storage"




def run_llm(query: str, chat_history=None):
    if chat_history is None:
        chat_history = []
    embeddings = OpenAIEmbeddings(
        openai_api_key="enter key here")
    docsearch = Pinecone.from_existing_index(
        index_name=index_name, embedding=embeddings)
    chat = ChatOpenAI(verbose=True, temperature=0, model_name="gpt-4")

    qa = ConversationalRetrievalChain.from_llm(
        llm=chat, retriever=docsearch.as_retriever(), return_source_documents=True)
    return qa({"question": query, "chat_history": chat_history})
